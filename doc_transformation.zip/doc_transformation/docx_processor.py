# docx_processor.py

import zipfile
import ollama
from lxml import etree
from copy import deepcopy
from ollama_client import OllamaClient

# Instantiate once at module‐level
_client = OllamaClient(model="deepseek-r1:1.5b", base_url="http://localhost:11434")

# XML namespaces needed for Word documents
NS = {
    'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
}
etree.register_namespace('w', NS['w'])

def _get_paragraph_text(p_element):
    """Extracts plain text from a paragraph's XML element."""
    return ''.join(p_element.xpath('.//w:t/text()', namespaces=NS))

def _extract_changes_from_english_docx(docx_path):
    """
    Parses the English DOCX using lxml to find all insertions and deletions.
    Returns a list of change dictionaries, each containing the change type, text,
    and the full original paragraph text for context.
    """
    changes = []
    with zipfile.ZipFile(docx_path, 'r') as docx_zip:
        xml_content = docx_zip.read('word/document.xml')
        root = etree.fromstring(xml_content)

        for p in root.xpath('//w:body/w:p', namespaces=NS):
            # Reconstruct the original paragraph text (ignoring insertions, including deletions)
            original_paragraph_text = ""
            for run in p.xpath('./w:r', namespaces=NS):
                if run.xpath('.//w:delText', namespaces=NS):
                    original_paragraph_text += ''.join(run.xpath('.//w:delText/text()', namespaces=NS))
                elif not run.xpath('.//w:ins', namespaces=NS):
                    original_paragraph_text += ''.join(run.xpath('.//w:t/text()', namespaces=NS))
            
            original_paragraph_text = original_paragraph_text.strip()
            if not original_paragraph_text:
                continue

            # Find insertions and deletions in the current paragraph
            insertions = p.xpath('.//w:ins', namespaces=NS)
            deletions = p.xpath('.//w:del', namespaces=NS)

            for ins in insertions:
                inserted_text = ''.join(ins.xpath('.//w:t/text()', namespaces=NS)).strip()
                if inserted_text:
                    changes.append({
                        'type': 'insertion',
                        'text': inserted_text,
                        'context': original_paragraph_text
                    })
            
            for dele in deletions:
                deleted_text = ''.join(dele.xpath('.//w:delText/text()', namespaces=NS)).strip()
                if deleted_text:
                    changes.append({
                        'type': 'deletion',
                        'text': deleted_text,
                        'context': original_paragraph_text
                    })
    return changes

def _get_llm_response(prompt: str) -> str:
    """Sends a prompt to Ollama and returns the cleaned response."""
    if not _client.is_available():
        raise ConnectionError("Ollama server not available or model not loaded.")

    result = _client.query(prompt)
    if result is None:
        raise ConnectionError("Ollama query failed or returned no text.")
    return result


def _create_updated_docx(chinese_path, output_path, changes, update_status_callback):
    """
    Creates the final Chinese document with tracked changes.
    This is the core of the hybrid logic.
    """
    with zipfile.ZipFile(chinese_path, 'r') as z_in:
        chinese_xml_content = z_in.read('word/document.xml')
        chinese_root = etree.fromstring(chinese_xml_content)
        
        # Create a map of Chinese paragraph text to its XML element for easy lookup
        chinese_para_map = { _get_paragraph_text(p): p for p in chinese_root.xpath('//w:body/w:p', namespaces=NS) }
        all_chinese_paras = list(chinese_para_map.keys())

    # Process each change found in the English document
    for i, change in enumerate(changes):
        update_status_callback(f"Processing change {i+1}/{len(changes)} ({change['type']})...")
        
        # Build the bulleted list once, outside the f-string
        bullet_list = "\n- ".join(all_chinese_paras)

        alignment_prompt = (
            "You are a text-matching assistant. Find the exact Chinese paragraph from the list below "
            "that is the translation of the given English paragraph.\n\n"
            f"English Paragraph:\n\"{change['context']}\"\n\n"
            "Chinese Paragraph List:\n"
            f"- {bullet_list}\n\n"
            "Respond with only the single, exact matching Chinese paragraph from the list."
        )
        target_chinese_text = _get_llm_response(alignment_prompt)

        if not target_chinese_text or target_chinese_text not in chinese_para_map:
            update_status_callback(f"Warning: LLM failed to align context: '{change['context'][:40]}...'. Skipping.")
            continue
            
        target_para_element = chinese_para_map[target_chinese_text]

        # 2. LLM EDITING: Ask the LLM to perform the precise edit
        if change['type'] == 'insertion':
            prompt = (
                f"You are a translator. Translate the following English phrase to Chinese. Respond with ONLY the Chinese translation.\n\n"
                f"English Phrase: \"{change['text']}\""
            )
            text_to_insert = _get_llm_response(prompt)
            
            # Find a good position to insert the text
            position_prompt = (
                f"You are a text-editing assistant. Find the best position to insert this Chinese text in the paragraph.\n\n"
                f"Chinese Paragraph: {target_chinese_text}\n"
                f"Text to Insert: {text_to_insert}\n\n"
                f"Respond with only a number representing the character index (0-based) where the text should be inserted."
            )
            try:
                position = int(_get_llm_response(position_prompt))
                # Ensure position is within bounds
                position = max(0, min(position, len(target_chinese_text)))
            except (ValueError, TypeError):
                # Default to end of paragraph if LLM doesn't return a valid position
                position = len(target_chinese_text)
            
            # We need to find which run contains this position
            runs = target_para_element.xpath('./w:r', namespaces=NS)
            current_pos = 0
            target_run_index = None
            offset_in_run = None
            
            for i, run in enumerate(runs):
                run_text = ''.join(run.xpath('.//w:t/text()', namespaces=NS))
                if current_pos <= position < current_pos + len(run_text):
                    target_run_index = i
                    offset_in_run = position - current_pos
                    break
                current_pos += len(run_text)
            
            # If we couldn't find a run (e.g., empty paragraph), append to the end
            if target_run_index is None:
                # Create new XML elements for the insertion with proper track changes markup
                new_run = etree.Element(etree.QName(NS['w'], 'r'))
                ins_element = etree.SubElement(new_run, etree.QName(NS['w'], 'ins'), {
                    etree.QName(NS['w'], 'author'): "AutoUpdater",
                    etree.QName(NS['w'], 'date'): "2023-01-01T00:00:00Z",
                    etree.QName(NS['w'], 'id'): str(i+1000)  # Unique ID
                })
                t_element = etree.SubElement(ins_element, etree.QName(NS['w'], 't'))
                t_element.text = text_to_insert
                t_element.set(etree.QName("{http://www.w3.org/XML/1998/namespace}space"), "preserve")
                target_para_element.append(new_run)
            else:
                # Split the run at the insertion point
                target_run = runs[target_run_index]
                run_text = ''.join(target_run.xpath('.//w:t/text()', namespaces=NS))
                
                # Create three runs: before insertion, insertion with track changes, after insertion
                if offset_in_run > 0:
                    # Create "before" run
                    before_run = deepcopy(target_run)
                    for t in before_run.xpath('.//w:t', namespaces=NS):
                        t.text = run_text[:offset_in_run]
                        t.set(etree.QName("{http://www.w3.org/XML/1998/namespace}space"), "preserve")
                    
                    # Insert before run
                    target_para_element.insert(target_para_element.index(target_run), before_run)
                
                # Create insertion run with track changes
                ins_run = etree.Element(etree.QName(NS['w'], 'r'))
                ins_element = etree.SubElement(ins_run, etree.QName(NS['w'], 'ins'), {
                    etree.QName(NS['w'], 'author'): "AutoUpdater",
                    etree.QName(NS['w'], 'date'): "2023-01-01T00:00:00Z",
                    etree.QName(NS['w'], 'id'): str(i+1000)  # Unique ID
                })
                t_element = etree.SubElement(ins_element, etree.QName(NS['w'], 't'))
                t_element.text = text_to_insert
                t_element.set(etree.QName("{http://www.w3.org/XML/1998/namespace}space"), "preserve")
                
                # Insert the insertion run
                target_para_element.insert(target_para_element.index(target_run) + (1 if offset_in_run > 0 else 0), ins_run)
                
                if offset_in_run < len(run_text):
                    # Create "after" run
                    after_run = deepcopy(target_run)
                    for t in after_run.xpath('.//w:t', namespaces=NS):
                        t.text = run_text[offset_in_run:]
                        t.set(etree.QName("{http://www.w3.org/XML/1998/namespace}space"), "preserve")
                    
                    # Insert after run
                    target_para_element.insert(target_para_element.index(target_run) + (2 if offset_in_run > 0 else 1), after_run)
                
                # Remove the original run
                target_para_element.remove(target_run)
            
        elif change['type'] == 'deletion':
            prompt = (
                f"You are a text-editing assistant. Identify the phrase within the Chinese sentence that corresponds to the deleted English phrase.\n\n"
                f"Chinese Sentence:\n\"{target_chinese_text}\"\n\n"
                f"Deleted English Phrase:\n\"{change['text']}\"\n\n"
                f"Respond with ONLY the exact Chinese phrase to be deleted."
            )
            text_to_delete = _get_llm_response(prompt)
            
            if not text_to_delete or text_to_delete not in target_chinese_text:
                update_status_callback(f"Warning: LLM failed to identify deletion text: '{text_to_delete}'. Skipping.")
                continue
            
            # Find the position of the text to delete
            delete_pos = target_chinese_text.find(text_to_delete)
            
            # We need to find which runs contain this text
            runs = target_para_element.xpath('./w:r', namespaces=NS)
            current_pos = 0
            start_run_index = None
            end_run_index = None
            start_offset = None
            end_offset = None
            
            for i, run in enumerate(runs):
                run_text = ''.join(run.xpath('.//w:t/text()', namespaces=NS))
                run_start = current_pos
                run_end = current_pos + len(run_text)
                
                # Check if this run contains the start of the deletion
                if start_run_index is None and run_start <= delete_pos < run_end:
                    start_run_index = i
                    start_offset = delete_pos - run_start
                
                # Check if this run contains the end of the deletion
                if start_run_index is not None and run_start < delete_pos + len(text_to_delete) <= run_end:
                    end_run_index = i
                    end_offset = delete_pos + len(text_to_delete) - run_start
                    break
                
                current_pos += len(run_text)
            
            if start_run_index is None or end_run_index is None:
                update_status_callback(f"Warning: Could not locate deletion text in runs. Skipping.")
                continue
            
            # Handle the case where deletion spans multiple runs
            if start_run_index == end_run_index:
                # Deletion is within a single run
                run = runs[start_run_index]
                run_text = ''.join(run.xpath('.//w:t/text()', namespaces=NS))
                
                # Create three parts: before deletion, deletion with track changes, after deletion
                if start_offset > 0:
                    # Create "before" run
                    before_run = deepcopy(run)
                    for t in before_run.xpath('.//w:t', namespaces=NS):
                        t.text = run_text[:start_offset]
                        t.set(etree.QName("{http://www.w3.org/XML/1998/namespace}space"), "preserve")
                    
                    # Insert before run
                    target_para_element.insert(target_para_element.index(run), before_run)
                
                # Create deletion run with track changes
                del_run = etree.Element(etree.QName(NS['w'], 'r'))
                del_element = etree.SubElement(del_run, etree.QName(NS['w'], 'del'), {
                    etree.QName(NS['w'], 'author'): "AutoUpdater",
                    etree.QName(NS['w'], 'date'): "2023-01-01T00:00:00Z",
                    etree.QName(NS['w'], 'id'): str(i+2000)  # Unique ID
                })
                del_text = etree.SubElement(del_element, etree.QName(NS['w'], 'delText'))
                del_text.text = text_to_delete
                del_text.set(etree.QName("{http://www.w3.org/XML/1998/namespace}space"), "preserve")
                
                # Insert the deletion run
                target_para_element.insert(target_para_element.index(run) + (1 if start_offset > 0 else 0), del_run)
                
                if end_offset < len(run_text):
                    # Create "after" run
                    after_run = deepcopy(run)
                    for t in after_run.xpath('.//w:t', namespaces=NS):
                        t.text = run_text[end_offset:]
                        t.set(etree.QName("{http://www.w3.org/XML/1998/namespace}space"), "preserve")
                    
                    # Insert after run
                    target_para_element.insert(target_para_element.index(run) + (2 if start_offset > 0 else 1), after_run)
                
                # Remove the original run
                target_para_element.remove(run)
            else:
                # Deletion spans multiple runs - more complex case
                # Handle first run (partial)
                first_run = runs[start_run_index]
                first_run_text = ''.join(first_run.xpath('.//w:t/text()', namespaces=NS))
                
                if start_offset > 0:
                    # Create "before" run for first run
                    before_run = deepcopy(first_run)
                    for t in before_run.xpath('.//w:t', namespaces=NS):
                        t.text = first_run_text[:start_offset]
                        t.set(etree.QName("{http://www.w3.org/XML/1998/namespace}space"), "preserve")
                    
                    # Insert before run
                    target_para_element.insert(target_para_element.index(first_run), before_run)
                
                # Create deletion run for first part
                del_run1 = etree.Element(etree.QName(NS['w'], 'r'))
                del_element1 = etree.SubElement(del_run1, etree.QName(NS['w'], 'del'), {
                    etree.QName(NS['w'], 'author'): "AutoUpdater",
                    etree.QName(NS['w'], 'date'): "2023-01-01T00:00:00Z",
                    etree.QName(NS['w'], 'id'): str(i+2000)  # Unique ID
                })
                del_text1 = etree.SubElement(del_element1, etree.QName(NS['w'], 'delText'))
                del_text1.text = first_run_text[start_offset:]
                del_text1.set(etree.QName("{http://www.w3.org/XML/1998/namespace}space"), "preserve")
                
                # Insert the first deletion run
                target_para_element.insert(target_para_element.index(first_run) + (1 if start_offset > 0 else 0), del_run1)
                
                # Handle middle runs (complete deletion)
                for j in range(start_run_index + 1, end_run_index):
                    middle_run = runs[j]
                    middle_run_text = ''.join(middle_run.xpath('.//w:t/text()', namespaces=NS))
                    
                    # Create deletion run for middle part
                    del_run_mid = etree.Element(etree.QName(NS['w'], 'r'))
                    del_element_mid = etree.SubElement(del_run_mid, etree.QName(NS['w'], 'del'), {
                        etree.QName(NS['w'], 'author'): "AutoUpdater",
                        etree.QName(NS['w'], 'date'): "2023-01-01T00:00:00Z",
                        etree.QName(NS['w'], 'id'): str(i+2000)  # Same ID as first part
                    })
                    del_text_mid = etree.SubElement(del_element_mid, etree.QName(NS['w'], 'delText'))
                    del_text_mid.text = middle_run_text
                    del_text_mid.set(etree.QName("{http://www.w3.org/XML/1998/namespace}space"), "preserve")
                    
                    # Replace the middle run with deletion
                    target_para_element.insert(target_para_element.index(middle_run), del_run_mid)
                    target_para_element.remove(middle_run)
                
                # Handle last run (partial)
                last_run = runs[end_run_index]
                last_run_text = ''.join(last_run.xpath('.//w:t/text()', namespaces=NS))
                
                # Create deletion run for last part
                del_run_last = etree.Element(etree.QName(NS['w'], 'r'))
                del_element_last = etree.SubElement(del_run_last, etree.QName(NS['w'], 'del'), {
                    etree.QName(NS['w'], 'author'): "AutoUpdater",
                    etree.QName(NS['w'], 'date'): "2023-01-01T00:00:00Z",
                    etree.QName(NS['w'], 'id'): str(i+2000)  # Same ID as first part
                })
                del_text_last = etree.SubElement(del_element_last, etree.QName(NS['w'], 'delText'))
                del_text_last.text = last_run_text[:end_offset]
                del_text_last.set(etree.QName("{http://www.w3.org/XML/1998/namespace}space"), "preserve")
                
                # Insert the last deletion run
                target_para_element.insert(target_para_element.index(last_run), del_run_last)
                
                if end_offset < len(last_run_text):
                    # Create "after" run for last run
                    after_run = deepcopy(last_run)
                    for t in after_run.xpath('.//w:t', namespaces=NS):
                        t.text = last_run_text[end_offset:]
                        t.set(etree.QName("{http://www.w3.org/XML/1998/namespace}space"), "preserve")
                    
                    # Insert after run
                    target_para_element.insert(target_para_element.index(last_run) + 1, after_run)
                
                # Remove original runs
                target_para_element.remove(first_run)
                target_para_element.remove(last_run)
            
    # Write the modified XML to the new DOCX file
    final_xml_string = etree.tostring(chinese_root, pretty_print=True, xml_declaration=True, encoding='UTF-8', standalone=True)
    with zipfile.ZipFile(chinese_path, 'r') as z_in:
        with zipfile.ZipFile(output_path, 'w') as z_out:
            for item in z_in.infolist():
                if item.filename != 'word/document.xml':
                    z_out.writestr(item, z_in.read(item.filename))
            z_out.writestr('word/document.xml', final_xml_string)


def run_document_processing(english_path, chinese_path, output_path, update_status_callback):
    """Main orchestrator function called by the GUI."""
    try:
        update_status_callback("Step 1/3: Parsing English document for changes...")
        changes = _extract_changes_from_english_docx(english_path)
        if not changes:
            update_status_callback("Complete: No tracked changes found in the English document.")
            return

        update_status_callback(f"Found {len(changes)} changes. Step 2/3: Applying changes via LLM...")
        _create_updated_docx(chinese_path, output_path, changes, update_status_callback)
        
        update_status_callback(f"Step 3/3: Finalizing document.\nProcessing complete! Output saved to:\n{output_path}")

    except Exception as e:
        update_status_callback(f"An error occurred: {e}")
